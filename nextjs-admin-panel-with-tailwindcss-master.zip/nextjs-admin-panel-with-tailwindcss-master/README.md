# NextJs Tailwind Admin Panle

## Simple NextJs Tailwind Admin Panel for starting background panel. you can add extra feature like as modal or other features.

---

## Sample Page One

## ![This is a alt text.](/public/01.png)

# Sample Page Two

## ![This is a alt text.](/public/02.png)

---

# Sample Page Three

## ![This is a alt text.](/public/03.png)

---

# Sample Page Four

## ![This is a alt text.](/public/04.png)

---

# Sample Page Five

## ![This is a alt text.](/public/05.png)

---

## Install

npm install <br />
npm run dev

---

## Credits

Inspired by https://codepen.io/azrikahar/pen/abZzaga
